#!/bin/sh

if [ -n "$(command -v dpkg)" ]; then
    dpkg --purge rmmagent
elif [ -n "$(command -v rpm)" ]; then
    rpm --erase rmmagent
else
    echo "No valid Linux toolset detected: checked dpkg, rpm."
    echo "Abotred."
    exit 1
fi
